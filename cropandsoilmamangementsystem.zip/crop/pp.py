import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score
import joblib


data = pd.read_csv("pest_prevention.csv")  

le_crop = LabelEncoder()
le_soil = LabelEncoder()
le_season = LabelEncoder()
le_prevention = LabelEncoder()

data["crop_type_enc"] = le_crop.fit_transform(data["crop_type"])
data["soil_type_enc"] = le_soil.fit_transform(data["soil_type"])
data["season_enc"] = le_season.fit_transform(data["season"])
data["prevention_enc"] = le_prevention.fit_transform(data["prevention"])

X = data[["crop_type_enc", "soil_type_enc", "temperature", "humidity", "soil_moisture", "season_enc"]]
y = data["prevention_enc"]


X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)


model = RandomForestClassifier(n_estimators=100, random_state=42)
model.fit(X_train, y_train)


y_pred = model.predict(X_test)
print("Accuracy:", accuracy_score(y_test, y_pred))


joblib.dump(model, "pest_prevention_model.pkl")
joblib.dump(le_crop, "le_crop_pp.pkl")
joblib.dump(le_soil, "le_soil_pp.pkl")
joblib.dump(le_season, "le_season_pp.pkl")
joblib.dump(le_prevention, "le_prevention.pkl")

print("Pest Prevention model and encoders saved successfully!")