import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_absolute_error, r2_score
from sklearn.preprocessing import LabelEncoder
import joblib

# Load dataset
data = pd.read_csv("Irr.csv")

# Encode categorical columns
le_crop = LabelEncoder()
le_soil = LabelEncoder()

data["crop_type_enc"] = le_crop.fit_transform(data["crop_type"])
data["soil_type_enc"] = le_soil.fit_transform(data["soil_type"])

# Features and target
X = data[["soil_moisture", "temperature", "humidity", "rainfall",
          "crop_type_enc", "soil_type_enc"]]

y = data["irrigation_required"]

# Train-test split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Model
model = RandomForestRegressor(n_estimators=200, random_state=42)
model.fit(X_train, y_train)

# Predictions
y_pred = model.predict(X_test)

# Evaluation
print("MAE:", mean_absolute_error(y_test, y_pred))
print("R² Score:", r2_score(y_test, y_pred))

# Save model + encoders
joblib.dump(model, "irrigation_model.pkl")
joblib.dump(le_crop, "crop_encoder.pkl")
joblib.dump(le_soil, "soil_encoder.pkl")

print("Model saved as irrigation_model.pkl")
print("Encoders saved as crop_encoder.pkl and soil_encoder.pkl")
