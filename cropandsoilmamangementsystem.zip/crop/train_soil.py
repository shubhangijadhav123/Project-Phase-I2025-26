import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn.ensemble import RandomForestClassifier
import joblib


data = pd.read_csv("fertilizer.csv")


le_soil = LabelEncoder()
le_fert = LabelEncoder()

data["Soil Type"] = le_soil.fit_transform(data["Soil Type"])
data["Fertilizer Name"] = le_fert.fit_transform(data["Fertilizer Name"])


X = data.drop(["Fertilizer Name"], axis=1)
y = data["Fertilizer Name"]


X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
model = RandomForestClassifier(n_estimators=200, random_state=42)
model.fit(X_train, y_train)
acc = model.score(X_test, y_test)
print(f"Fertilizer Model Accuracy: {acc*100:.2f}%")


joblib.dump(model, "soil_model.pkl")
joblib.dump(le_soil, "soil_encoder.pkl")
joblib.dump(le_fert, "fertilizer_encoder.pkl")
print("Model and encoders saved successfully!")
