from flask import Flask, request, render_template
import pandas as pd
from rapidfuzz import process

app = Flask(__name__)


df = pd.read_csv("prevent.csv")
crop_list = df['Crop'].unique()

@app.route('/', methods=['GET', 'POST'])
def home():
    tips = []
    user_crop = ''
    
    if request.method == 'POST':
        user_crop = request.form['crop'].strip()
        
        best_match = process.extractOne(user_crop, crop_list)
        if best_match:
            crop_name = best_match[0]
           
            tips = df[df['Crop'].str.lower() == crop_name.lower()]['Prevention'].tolist()
    
    return render_template('prevent.html', tips=tips, crop=user_crop)

if __name__ == '__main__':
    app.run(debug=True)
