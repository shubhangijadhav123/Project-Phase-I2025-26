from flask import Flask, render_template, request
import joblib
import numpy as np

app = Flask(__name__)

crop_model = joblib.load("crop_model.pkl")
soil_model = joblib.load("soil_model.pkl")
le_soil = joblib.load("soil_encoder.pkl")
le_fert = joblib.load("fertilizer_encoder.pkl")
irrigation_model = joblib.load("irrigation_model.pkl")
le_crop = joblib.load("crop_encoder.pkl")


pest_model = joblib.load("pest_risk_model.pkl")
le_crop_pest = joblib.load("le_crop.pkl")
le_soil_pest = joblib.load("le_soil.pkl")
le_season = joblib.load("le_season.pkl")

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/crop")
def crop_page():
    return render_template("crop.html")

@app.route("/predict_crop", methods=["POST"])
def predict_crop():
    N = float(request.form["N"])
    P = float(request.form["P"])
    K = float(request.form["K"])
    temperature = float(request.form["temperature"])
    humidity = float(request.form["humidity"])
    ph = float(request.form["ph"])
    rainfall = float(request.form["rainfall"])

    features = np.array([[N, P, K, temperature, humidity, ph, rainfall]])
    prediction = crop_model.predict(features)[0]

    return render_template("crop.html", result=f"Recommended Crop: {prediction}")

@app.route("/fertilizer")
def fertilizer_page():
    soil_types = list(le_soil.classes_)
    return render_template("fertilizer.html", soil_types=soil_types)

@app.route("/predict_fertilizer", methods=["POST"])
def predict_fertilizer():
    temperature = float(request.form["temperature"])
    humidity = float(request.form["humidity"])
    moisture = float(request.form["moisture"])
    soil_type = request.form["soil_type"]
    N = float(request.form["N"])
    P = float(request.form["P"])
    K = float(request.form["K"])

    soil_enc = le_soil.transform([soil_type])[0]
    features = np.array([[temperature, humidity, moisture, soil_enc, N, P, K]])
    prediction = soil_model.predict(features)
    fertilizer = le_fert.inverse_transform(prediction)[0]

    return render_template("fertilizer.html", result=f"Recommended Fertilizer: {fertilizer}")

@app.route("/irrigation")
def irrigation_page():
    crop_names = list(le_crop.classes_)
    soil_types = list(le_soil.classes_)
    return render_template("irrigation.html", crop_names=crop_names, soil_types=soil_types)

@app.route("/predict_irrigation", methods=["POST"])
def predict_irrigation():
    soil = float(request.form["soil"])
    temperature = float(request.form["temperature"])
    humidity = float(request.form["humidity"])
    rainfall = float(request.form["rainfall"])
    crop_name = request.form["crop"]
    soil_type = request.form["soil_type"]

    crop_code = le_crop.transform([crop_name])[0]
    soil_code = le_soil.transform([soil_type])[0]

    features = np.array([[soil, temperature, humidity, rainfall, crop_code, soil_code]])
    prediction = irrigation_model.predict(features)[0]

    return render_template(
        "irrigation.html",
        result=f"Required Irrigation: {prediction} liters",
        crop_names=list(le_crop.classes_),
        soil_types=list(le_soil.classes_)
    )


@app.route("/pest")
def pest_page():
    crop_names = list(le_crop_pest.classes_)
    soil_types = list(le_soil_pest.classes_)
    seasons = list(le_season.classes_)
    return render_template("pest.html", crop_names=crop_names, soil_types=soil_types, seasons=seasons)

@app.route("/predict_pest", methods=["POST"])
def predict_pest():
    crop_name = request.form["crop"]
    soil_type = request.form["soil_type"]
    temperature = float(request.form["temperature"])
    humidity = float(request.form["humidity"])
    soil_moisture = float(request.form["soil_moisture"])
    season = request.form["season"]

    crop_code = le_crop_pest.transform([crop_name])[0]
    soil_code = le_soil_pest.transform([soil_type])[0]
    season_code = le_season.transform([season])[0]

    features = np.array([[crop_code, soil_code, temperature, humidity, soil_moisture, season_code]])
    prediction = pest_model.predict(features)[0]

    return render_template(
        "pest.html",
        result=f"Pest Risk: {prediction}",
        crop_names=list(le_crop_pest.classes_),
        soil_types=list(le_soil_pest.classes_),
        seasons=list(le_season.classes_)
    )
import pandas as pd
from sklearn.preprocessing import MultiLabelBinarizer
import joblib

disease_model = joblib.load("disease_model.pkl")
le_crop_disease = joblib.load("le_crop_disease.pkl")
le_severity_disease = joblib.load("le_severity_disease.pkl")
mlb_symptoms = joblib.load("mlb_symptoms.pkl")
le_disease = joblib.load("le_disease.pkl")

disease_data = pd.read_csv("disease.csv")

@app.route("/disease")
def disease_page():
    crops = list(le_crop_disease.classes_)
    return render_template("disease.html", crops=crops, symptoms=[])

@app.route("/get_symptoms", methods=["POST"])
def get_symptoms():
    crop_name = request.form["crop"]
    crop_data = disease_data[disease_data["Crop"] == crop_name]
    all_symptoms = set()
    for s in crop_data["Symptoms"]:
        for symptom in s.split(","):
            all_symptoms.add(symptom.strip())
    symptoms_list = sorted(list(all_symptoms))
    return {"symptoms": symptoms_list}

@app.route("/predict_disease", methods=["POST"])
def predict_disease():
    crop_name = request.form["crop"]
    severity_name = request.form["severity"]
    selected_symptoms = request.form.getlist("symptoms")

    crop_enc = le_crop_disease.transform([crop_name])[0]
    severity_enc = le_severity_disease.transform([severity_name])[0]
    symptoms_encoded = mlb_symptoms.transform([selected_symptoms])[0]

    features = np.concatenate(([crop_enc, severity_enc], symptoms_encoded))
    features = features.reshape(1, -1)

    prediction = disease_model.predict(features)[0]
    disease_name = le_disease.inverse_transform([prediction])[0]

    return render_template(
        "disease.html",
        result=f"Disease: {disease_name}",
        crops=list(le_crop_disease.classes_),
        symptoms=selected_symptoms
    )
from rapidfuzz import process  
import pandas as pd

df = pd.read_csv("prevent.csv")  

@app.route('/prevent', methods=['GET', 'POST'])
def crop_prevention():
    tips = []
    user_crop = ''
    crops = sorted(df['Crop'].unique())

    if request.method == 'POST':
        user_crop = request.form['crop']
        best_match = process.extractOne(user_crop, crops)
        if best_match:
            crop_name = best_match[0]
            tips = df[df['Crop'].str.lower() == crop_name.lower()]['Prevention'].tolist()
    return render_template('prevent.html', tips=tips, crop=user_crop, crops=crops)

if __name__ == "__main__":
    app.run(debug=True)