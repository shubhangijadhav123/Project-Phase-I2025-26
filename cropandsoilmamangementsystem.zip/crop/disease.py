import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.preprocessing import LabelEncoder
from sklearn.neighbors import KNeighborsClassifier
from sklearn.model_selection import train_test_split
import joblib

data = pd.read_csv("disease.csv")

data["Crop"] = data["Crop"].astype(str)
data["Severity"] = data["Severity"].astype(str)
data["Symptoms"] = data["Symptoms"].astype(str)
data["Disease"] = data["Disease"].astype(str)

le_crop = LabelEncoder()
data["crop_enc"] = le_crop.fit_transform(data["Crop"])

le_severity = LabelEncoder()
data["severity_enc"] = le_severity.fit_transform(data["Severity"])

tfidf = TfidfVectorizer()
symptom_features = tfidf.fit_transform(data["Symptoms"])

import numpy as np
X = np.hstack([data[["crop_enc", "severity_enc"]].values, symptom_features.toarray()])
y = data["Disease"]

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

knn = KNeighborsClassifier(n_neighbors=3)
knn.fit(X_train, y_train)

joblib.dump(knn, "knn_disease_model.pkl")
joblib.dump(tfidf, "tfidf_vectorizer.pkl")
joblib.dump(le_crop, "le_crop.pkl")
joblib.dump(le_severity, "le_severity.pkl")

print("K-NN model trained and saved successfully!")
